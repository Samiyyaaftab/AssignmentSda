// Coffee class now extends Menu to inherit menu properties
public class Coffee extends Menu {

    
    public Coffee(int id, String name, double price) {
        super(id, name, price);
    }

    
    public Coffee(int id, String name, double price, int quantity) {
        super(id, name, price, quantity);
    }

  
    @Override
    public String toString() {
        return super.toString();
    }
}
