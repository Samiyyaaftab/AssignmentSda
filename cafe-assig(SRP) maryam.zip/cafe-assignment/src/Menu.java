// Menu class to handle common menu properties
public class Menu {
    private int id;
    private String name;
    private double price;
    private int quantity;

    
    public Menu(int id, String name, double price, int quantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = (quantity > 0) ? quantity : 1; 
    }

    
    public Menu(int id, String name, double price) {
        this(id, name, price, 1);
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    // Setters 
    public void setQuantity(int quantity) {
        if (quantity > 0) {
            this.quantity = quantity;
        }
    }

    
    @Override
    public String toString() {
        return id + ". " + name + " - " + price + " SAR (Qty: " + quantity + ")";
    }
}
