
import java.util.List;

class Billing {
    private static final double TAX_RATE = 0.15;

    public double calculateSubTotal(List<OrderItem> orderList) {
        double subTotal = 0;
        for (OrderItem item : orderList) {
            subTotal += item.getPrice() * item.getQuantity();
        }
        return subTotal;
    }

    public void printBill(List<OrderItem> orderList) {
        double subTotal = calculateSubTotal(orderList);
        double tax = subTotal * TAX_RATE;
        double total = subTotal + tax;

        System.out.println("********** Bill **********");
        System.out.printf("Sub Total: %.2f SAR%n", subTotal);
        System.out.printf("Tax (%.0f%%): %.2f SAR%n", TAX_RATE * 100, tax);
        System.out.printf("Total: %.2f SAR%n", total);

        if (!orderList.isEmpty()) {
            System.out.println("\nOrdered Items:");
            int id = 1;
            for (OrderItem item : orderList) {
                System.out.printf("%d. %s - %.2f SAR (Qty: %d)%n", id++, item.getName(), item.getPrice(), item.getQuantity());
            }
        }
    }
}
