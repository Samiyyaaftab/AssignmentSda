
import java.util.Scanner;

public class Customer extends staff {
    private final RatingService ratingService;
    private final PaymentService paymentService;

    public Customer() {
        this.ratingService = new RatingService();
        this.paymentService = new PaymentService();
    }

    public void rateService() {
        ratingService.collectRating();
    }

    public void payOrder() {
        paymentService.processPayment();
    }
}
